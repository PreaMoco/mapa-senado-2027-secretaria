---
name: canva-proposicao-legislativa
description: Resume proposição legislativa (PL, PLP, PEC, MPV, PLV, PDL, PRS) em linguagem simples, com fontes rastreáveis nas páginas de tramitação da Câmara e do Senado, e, após aprovação, monta o Canva informativo (A4) do item da pauta do Plenário do Senado (Estilo A). Use sempre que o usuário enviar uma pauta do Plenário, citar "ITEM X" com uma proposição, ou pedir resumo, card, infográfico, arte, Canva ou material informativo de matéria legislativa — mesmo que não diga "Canva" nem "resumo".
---

# Resumo de proposição + Canva informativo (pauta do Plenário)

Fluxo em duas etapas, sempre nesta ordem: **(1) pesquisa e resumo → aprovação do Eduardo → (2) Canva → aprovação da prévia → salvar (commit).** Nunca montar o Canva antes de o resumo ser aprovado; nunca dar commit antes de o Eduardo aprovar a prévia.

Público: senadores, assessores e servidores da SGM. Linguagem simples, direta, sem juridiquês desnecessário.

## 0. Dados de entrada

Para cada item, confirmar antes de começar (perguntar só o que faltar):
- Rótulo do item (ex.: "ITEM 3") e data da sessão — o Eduardo informa.
- Espécie, número e ano (PL, PLP, PEC, MPV, PLV, PDL, PRS…).
- Estilo do Canva: **A** é o único padrão (seção 3.3). Outro estilo só se o Eduardo especificar.
- Se a espécie ainda não tem exemplo aprovado na seção 3 (ex.: PRS), **pedir ao Eduardo um Canva pronto** dessa espécie antes de montar; sem exemplo, partir do modelo mais próximo e avisar.
- Antes da etapa 2, conferir se as ferramentas do Canva estão disponíveis na conversa; se não estiverem, buscar o conector do Canva e oferecê-lo ao Eduardo antes de começar (não montar nada fora do Canva).
- Testar o acesso aos modelos (`read-design`) antes de montar. Se vier "permission_denied" ou a busca de designs voltar vazia, o conector foi autorizado em outra conta/equipe: pedir ao Eduardo que desvincule e reconecte o Canva escolhendo, na tela "Select a team", a equipe que contém os modelos (conta atlsgm@senado.leg.br).

## 1. Pesquisa (roteiro obrigatório)

A base do resumo são as **páginas de tramitação da matéria em cada casa por onde passou** e os **documentos listados nelas**. Fontes externas entram só para complementar.

### 1.1 Senado
- Página da matéria: `https://www25.senado.leg.br/web/atividade/materias/-/materia/<código>` (WebSearch para achar o código; WebFetch para ler).
- Ler: ementa, autoria, texto em análise, relatorias, comissões, requerimentos (urgência, audiência, tramitação conjunta), emendas e situação atual.
- Abrir **todos os relatórios e pareceres** de comissão e de Plenário disponíveis (inclusive relatório ainda não votado, sinalizado como tal) e a justificação/exposição de motivos.

### 1.2 Câmara (se a matéria começou lá, ou é MPV/PLV)
- Ficha de tramitação: `https://www.camara.leg.br/proposicoesWeb/fichadetramitacao?idProposicao=<id>` (ou a página `camara.leg.br/propostas-legislativas/<id>`).
- Abrir **pareceres e relatórios das comissões e de Plenário** (incluindo parecer preliminar e de mérito de comissão especial ou mista), o texto aprovado (redação final / autógrafos) e a justificação original.
- Agência Câmara e demais notícias são **fontes externas** (ver 2.2).

### 1.3 Qual texto descrever
- Descrever o **texto que será votado no Senado** na data da sessão: em regra, o texto recebido da Câmara (autógrafos) ou, no Senado, o substitutivo/emendas propostos pelo relator, se houver. Dizer expressamente qual versão foi usada.
- Quando o relatório no Senado alterar o texto (emendas, substitutivo), indicar as mudanças em relação ao texto recebido.
- Conferir a situação **na data da sessão**: se algo mudou depois da última leitura (relator designado, urgência votada, parecer apresentado), atualizar.

### 1.4 Limitações de rede
- `legis.senado.leg.br/dadosabertos`, os PDFs `sdleg-getter` (relatórios, pareceres, avulsos, emendas) e os inteiros teores da Câmara (`prop_mostrarintegra`) costumam não abrir no ambiente — tentar uma vez; se falhar, pedir o PDF ao Eduardo ou usar o que estiver em páginas públicas.
- A ferramenta de leitura só abre links que já apareceram em resultado de busca ou em página lida. Se a página da matéria recusar, buscar ou abrir antes uma notícia da Agência Senado que tenha o link da matéria e tentar de novo.
- Alternativas que costumam abrir e valem como documento da tramitação:
  - **Notas taquigráficas** da reunião da comissão (`www25.senado.leg.br/web/atividade/notas-taquigraficas/-/notas/r/<nº>`): trazem a leitura do relatório e do voto e as emendas comentadas. Citar como "(Notas taquigráficas, 15ª Reunião CI, 02/09/2026)".
  - **Página bicameral** do Congresso (`congressonacional.leg.br/materias/materias-bicamerais/-/ver/<sigla>-<nº>-<ano>`): reproduz a ficha de tramitação da Câmara (relatores, pareceres, votações com placar, redação final, autógrafos).
- **Sempre avisar** quais documentos não puderam ser lidos ou só foram lidos em parte.

## 2. Resumo (para aprovação)

Bullet points, ~5 seções (pode variar). Sempre:
- **Contexto** — por que a proposta surgiu; histórico de tramitação relevante nas duas casas (datas, aprovações, relatores).
- **Objetivos** — os declarados na justificação, exposição de motivos ou pareceres, **indicando a fonte entre parênteses**; se as fontes divergirem, apontar a divergência.

Seções obrigatórias conforme a espécie:
- MPV: pressupostos constitucionais (relevância e urgência), prazo de vigência (data de perda de eficácia) e se tramita como MPV ou PLV.
- PEC: dispositivos constitucionais alterados, regras de transição e quórum/turnos.
- Matéria com impacto fiscal: adequação orçamentária e financeira (estimativa de impacto, compensação, LRF/LDO), conforme parecer.
- PDL de tratado: o que o decreto aprova e eventuais ressalvas/condicionantes.

Outras seções úteis: "O que a proposta muda / aprova" (por artigo ou eixo), "Pontos de debate" (críticas, apoios, resposta do texto).

### 2.1 Citação de documentos da tramitação
Informação tirada das páginas de tramitação ou de documentos listados nelas: citar **só o nome e a data do documento**, sem link, entre parênteses curtos. Ex.: (Parecer CAE, 12/03/2026), (Relatório Sen. Fulano, CCJ, 05/05/2026), (Exposição de Motivos nº 12/2026), (Parecer de Plenário, Câmara, 20/02/2026).

### 2.2 Fontes externas (link obrigatório)
Qualquer informação que **não** esteja nas páginas de tramitação nem nos documentos lá presentes (notícias, Agência Câmara/Senado, notas de entidades, frentes parlamentares, estudos, sites do Governo) deve vir com a **fonte e o link completo**, ex.: (Agência Câmara, 08/10/2025 — <link>).

### 2.3 Rastreabilidade (obrigatório)
- Todo fato relevante (parecer, votação, posição de entidade, número, data) indica a fonte, conforme 2.1 ou 2.2.
- Ao fim do resumo, incluir **"Fontes"**: (a) links das páginas de tramitação consultadas em cada casa; (b) lista dos documentos da tramitação usados (nome e data); (c) fontes externas com link e o que cada uma sustentou. Quando o Eduardo perguntar "de onde tirou isso?", apontar o documento exato.
- Dizer expressamente o que **não foi lido na íntegra** e o que não pôde ser aberto.
- **Não inserir interpretação própria como se fosse fato.** O cartão "Resposta do texto" apenas **descreve** o que o dispositivo diz (ex.: "o art. 2º determina aplicação conforme a Constituição e a LGPD"). Não afirmar que ele "responde" ou "endereça" críticas, salvo se uma fonte disser isso; se for leitura própria, marcar "(leitura do resumo)" e avisar.
- Críticas e apoios atribuídos a quem os fez, com a fonte.

### 2.4 Várias proposições de uma pauta
Quando o Eduardo enviar uma pauta com vários itens: pesquisar todos, enviar **todos os resumos numa só mensagem** (se ele pedir aprovação conjunta), destacar ressalvas por item e só montar os Canvas após a aprovação. Para cada item, propor relator ou relatora, tramitação e, se houver, um dado-chave para destaque. Item já feito e aprovado em outra sessão pode ser reaproveitado, se o Eduardo confirmar — mas conferir antes se a tramitação mudou (relator de Plenário designado, requerimentos novos de urgência, adiamento ou oitiva de comissão, emendas) e listar as atualizações necessárias no resumo e no Canva para aprovação.

Apresentar o texto e **parar** aguardando aprovação. O Canva pode condensar o texto aprovado, sem alterar conteúdo.

## 3. Canva

Página A4 (794×1123 px). Padrão: 1 página; qualquer espécie pode ter 2 páginas ou mais quando o tamanho ou a complexidade da matéria justificarem — avisar na prévia. Sempre trabalhar em **cópia** (`copy-design`) — nunca editar o original.

### 3.1 Autor/Autora e Relator/Relatora
- **Rótulos no Canva**: usar a forma conforme a pessoa — "Autor" ou "Autora", "Relator" ou "Relatora". **Nunca** "Autor(a)" nem "Relator(a)". Autoria de órgão: "Autor". Vários autores: rótulo conforme o primeiro autor.
- **Autor/Autora**: parlamentar (foto oficial) ou órgão (logo/brasão + legenda, ex.: "Presidência da República"). Vários autores: o primeiro + "e outros".
- **Relator/Relatora**, nesta ordem:
  1. **Relator de Plenário** no Senado, se designado (vale também para MPV/PLV).
  2. Senão, o relator da **última comissão** por onde a matéria passou.
  3. Senão, quadro **em branco**: rótulo "Relator" em cima, campo de foto vazio no meio e o texto "Nome (Partido/UF)" embaixo, como espaço a preencher.
- **Relator ad hoc**: se na comissão que define a relatoria o relatório foi lido ou votado por relator ad hoc em substituição ao designado, **usar como regra o relator designado** no Canva. Mesmo assim, **sempre informar** no resumo a existência do ad hoc (quem era o designado, quem atuou como ad hoc, em que data, e como a Agência Senado credita), para o Eduardo confirmar ou trocar.
- **Fotos oficiais — nunca usar outra fonte:**
  - Senador: `https://legis.senado.leg.br/senadores/fotos-oficiais/<código do parlamentar>`.
  - Deputado: a foto **com fundo branco** exibida na **Biografia completa** do deputado no site da Câmara (`https://www.camara.leg.br/deputados/<id>/biografia`). Não usar a miniatura `bandep` se ela não for essa mesma foto. Se não conseguir abrir a página ou obter a imagem, avisar e pedir a foto ao Eduardo.
  - Legenda: "Sen./Dep. Nome (SIGLA DO PARTIDO/UF)", com barra — ex.: "Sen. Carlos Fávaro (PSD/MT)", "Dep. Reginaldo Lopes (PT/MG)".
  - Partido divergente entre fontes (página da matéria, Agência Senado, notícias): usar o da biografia oficial atual (Senado ou Câmara) e avisar a divergência no resumo.

### 3.2 Elementos fixos
- **Cabeçalho**: faixa azul `#1456ad`, título "ITEM X - SIGLA Nº/ANO" (branco, negrito, ~40 px; ajustar largura para não quebrar), brasão + "Secretaria-Geral da Mesa" à esquerda, logo "SENADO FEDERAL" à direita. Variantes usadas nos exemplos aprovados: "ITEM ÚNICO - SIGLA Nº/ANO" e "EXTRAPAUTA - SIGLA Nº/ANO". Na 2ª página, faixa fina com o mesmo título.
- **Brasão de armas (canto superior esquerdo): usar sempre a versão mais clara** dos modelos PL 3453/2024 (`DAHT4fy8JfU`) e PL 6461/2019 (`DAHMGoF2gTw`) — no PL 3453/2024 é a imagem `MAEq8XX_daI`, 57×57 px, a ~43 px da borda esquerda e ~5 px do topo (conferir no PL 6461 antes de usar). Ao partir de modelo mais antigo, que tem brasão mais escuro, trocar com `update_fill` (asset_type image), mantendo tamanho e posição. Vale também para itens reaproveitados.
- **Ementa**: caixa azul-clara logo abaixo do cabeçalho, "EMENTA: …" em negrito, justificado, texto oficial sem alterações.
- **Quadro da direita**: Autor/Autora, Relator/Relatora e **TRAMITAÇÃO**.
- **Tramitação — só as etapas no Senado** (o histórico na Câmara vai no Contexto/linha do tempo):
  - Etapas: LEITURA → [comissões do Senado, com sigla, ex.: CAE, CAS, CRA, CCJ] → PLENÁRIO → destino final.
  - Destino final: SANÇÃO (PL, PLP, PLV); PROMULGAÇÃO (PEC, PDL, PRS, MPV aprovada sem alterações); "VOLTA À CÂMARA" quando o Senado alterar matéria iniciada lá (indicar como possibilidade se ainda não votada).
  - Etapa atual com **moldura vermelha** `#dd0b0b`.
  - Etiquetas laranja `#ff560d` (texto branco, negrito, ~10 px) junto à etapa: "Requerimento de urgência", "Urgência aprovada", "Decisão terminativa", "Tramitação conjunta" etc.
  - Palavras longas (PROMULGAÇÃO) em ~22 px e caixa larga para não quebrar.

### 3.3 Estilo A — estrutura dos exemplos (padrão)
**O Estilo A é o único padrão.** Os modelos da seção 3.8 não o substituem: acrescentam-se a ele como repertório de estilo (brasão claro, cartões com ícone, faixa-título etc.).

Partir da cópia de um Canva da mesma espécie: PDL 934/2025 `DAHadRalyk4`; MPV 1369/2026 `DAHTzxPMocE`; PL 3289/2026 `DAHR_Aws3E0`; PLP 186/2026 `DAHYGIOoxRU` (extrapauta, 2 págs.); PEC 221/2019 `DAHXPYWCvjY` (item único, 2 págs.). Blocos: CONTEXTO (verde), "O QUE O … APROVA/MUDA" (moldura azul), OBJETIVOS (moldura amarela), PONTOS DE DEBATE (moldura vermelha), ilustrações nos espaços livres.

Estrutura observada nos exemplos de espécies novas:
- **PLP 186/2026** (2 páginas): pág. 1 — OBJETIVOS (faixa verde), duas ilustrações com título, "O QUE MUDA PARA O …" em cartões com ícone (3 cartões + bullets abaixo); pág. 2 — blocos temáticos com ícone em círculo e faixa verde (ex.: REMISSÃO, CONTRAPARTIDAS E CONDIÇÕES, COMPRAS PÚBLICAS), bloco RESPONSABILIDADE FISCAL (faixa azul-clara) e linha do tempo horizontal "QUANDO VALE" (cartões com setas verdes).
- **PEC 221/2019** (2 páginas): pág. 1 — faixa-título temática (imagem), CONTEXTO (faixa azul-marinho), OBJETIVOS DA PROPOSTA (faixa dourada, destaques numéricos em laranja); pág. 2 — PRINCIPAIS ALTERAÇÕES CONSTITUCIONAIS (moldura verde, 2 colunas), imagem horizontal, REGRAS DE TRANSIÇÃO E EXCEÇÕES PREVISTAS (moldura coral, 2 colunas). Na tramitação, etiqueta verde "Parecer favorável" junto à comissão.

### 3.4 Outros estilos
Não há estilo B. Usar só o Estilo A (3.3); outro estilo apenas quando o Eduardo especificar (pedir a descrição ou um Canva de exemplo).

### 3.5 Ilustrações
Reaproveitar as dos modelos quando servirem; gerar as que faltarem com `generate-image` (estilo flat ou imagem realista temática, como o livro "Lei dos Cartórios" no PL 3453/2024; cores do Senado, sem pessoas reais identificáveis, sem logotipos de terceiros, sem texto dentro da imagem — exceto a faixa-título do assunto, ver 3.8), depois `update_fill` ou `insert_fill`. Informar os links "Open generated image" ao final.

### 3.6 Detalhes técnicos do Canva (aprendidos)
- `font_size` em `format_text` precisa ser **inteiro**.
- Para manter negrito parcial, usar `find_and_replace_text` em cada trecho (não `replace_text` no elemento inteiro). Quebras de linha na substituição criam novos bullets.
- Imagem desenquadrada: deixar a caixa na proporção da imagem e aplicar `crop_media` com top/left 0 e largura/altura iguais à caixa.
- Depois de cada lote de edições, conferir a miniatura: textos estourando caixas, palavras quebradas, sobreposições.
- Texto corrido: mínimo 12 px (preferir 13–14 px quando couber).
- Etiqueta de tramitação positiva (ex.: "Parecer favorável") pode ser verde, como no exemplo da PEC 221/2019; as demais seguem laranja `#ff560d`.

### 3.8 Estilo de referência (calibração)
Modelos de estilo, considerados os mais bonitos pelos usuários: **PL 3453/2024** `DAHT4fy8JfU` (1 pág.), **PL 6461/2019** `DAHMGoF2gTw` (2 págs.), **PDL 1203/2025** `DAHOur_HHg8` (1 pág.) e **PDL 266/2023** `DAHT9fGWaOA` (1 pág.; confirmado pelo Eduardo, que o havia citado como "PDL 226/2023"). Não são estilo único nem substituem o Estilo A (3.3): acrescentam-se a ele. Partir da cópia do modelo da espécie (3.3) e incorporar destes modelos os elementos que couberem; o brasão claro (3.2) vale sempre. Medidas em px na página A4 794×1123:
- **Cabeçalho**: faixa `#1456ad` de ponta a ponta (~85 px de altura) com padrão em marca-d'água a 12% de opacidade; brasão claro (ver 3.2); "Secretaria-Geral da Mesa" 10 px negrito branco sob o brasão; logo SENADO FEDERAL à direita (~84 px) com legenda de 8,6 px; título 40 px negrito branco centralizado.
- **Ementa**: caixa `#a7c5ed` a ~46% de opacidade, ~474 px de largura a 18 px da borda esquerda, texto de 12 px negrito justificado.
- **Quadro direito**: moldura preta arredondada (~263×549 px, a ~513 px da esquerda). Rótulos "Autor"/"Autora" e "Relator"/"Relatora" em 25 px negrito; fotos quadradas de ~112 px com moldura preta; legenda de 9,5 px negrito "Sen./Dep. Nome (PARTIDO/UF)". Tramitação em fundo `#c9d7e8`, título TRAMITAÇÃO 20 px `#1456ad`, etapas em 26 px ligadas por setas pontilhadas, etapa atual com moldura `#bd1429`, etiqueta "Parecer favorável" em verde `#008429` (10,7 px negrito branco; as demais etiquetas seguem laranja `#ff560d`).
- **Autor órgão da Câmara (PDL)**: logo da Câmara com legenda "Com. de <nome abreviado> (CD)", ex.: "Com. de Rel. Exteriores e Defesa Nacional (CD)".
- **Faixa-título do assunto**: imagem larga (~473×82 px) logo abaixo da ementa, com o nome do tema e, quando couber, o ato em subtítulo (ex.: "ACORDO INTERNACIONAL DO CAFÉ DE 2022"; "PL 3453/2024 — PRAZO PRESCRICIONAL DE SANÇÕES A NOTÁRIOS E REGISTRADORES").
- **Cartões de conteúdo**: cada bloco é um cartão com moldura de 4 px e fundo da mesma cor a ~12% de opacidade; ícone à esquerda do título (recolorido na cor do tema); título em MAIÚSCULAS, negrito, ~17 px, cor `#0e253b` (ou na cor do cartão); texto de 16 px justificado, entrelinha 1,4. O PL 3453/2024 usa moldura dourada `#c0a36b` com fundo `#cfac8a`; o PL 6461/2019 e o PDL 1203/2025 usam uma cor por cartão (azul, laranja/dourado, verde, roxo, vermelho, cinza). Alguns cartões podem ser de largura total (ex.: "PARTICIPAÇÃO DA ADMINISTRAÇÃO PÚBLICA").
- **Tamanho de texto**: preferir 14–16 px; descer a ~11–12 px só em páginas densas de 2 páginas (ex.: p. 2 do PL 6461/2019). Frases curtas, dado-chave em negrito (ex.: "5 (cinco) anos"). Avaliação do relator atribuída a ele: "Segundo a Relatora, …".
- **Imagens**: uma imagem grande de apoio temática no canto inferior esquerdo (foto realista ou ilustração) e cartões finais curtos ao lado (ex.: "SEGURANÇA JURÍDICA", "INTERESSE PÚBLICO"). Em PDL, cartão "BENEFÍCIOS PARA O BRASIL" ou "REGRAS IMPORTANTES" com os dados numéricos do acordo.
- **Estrutura por espécie observada**: PL 1 pág. — CONTEÚDO DO PROJETO, RAZÃO DA ALTERAÇÃO, faixa de contexto, cartões finais. PL 2 págs. — p. 1: caixa-resumo do assunto, depois cartões OBJETIVOS E REQUISITOS, CONTRATO e PARTICIPAÇÃO DA ADMINISTRAÇÃO PÚBLICA; p. 2: grade de cartões coloridos por eixo (cota, contratação facultativa, direitos, rescisão, conta especial, multas, outras alterações). PDL — bullets PRINCIPAIS OBJETIVOS (ou PRINCIPAIS MUDANÇAS PROPOSTAS) e cartões temáticos com ícone.

### 3.7 Revisão e entrega
1. Enviar a prévia (miniatura) e listar ressalvas (documentos não lidos, dados pendentes, urgência ainda não votada, relator ainda não designado etc.).
2. Só com aprovação explícita: `edit-design` com `finalize: "commit"`.
3. Entregar link de edição do Canva + links das imagens geradas.

## 4. Melhoria contínua da skill
Quando o Eduardo corrigir algo que vale para casos futuros (regra, cor, fonte, fluxo, truque técnico do Canva), propor ao fim da entrega o trecho a acrescentar ou alterar nesta skill, indicando a seção. Não alterar regras sem aprovação.

## Checklist
- [ ] Resumo aprovado antes do Canva
- [ ] Conector do Canva disponível antes da etapa 2
- [ ] Páginas de tramitação das duas casas lidas; relatórios e pareceres abertos (ou falha informada)
- [ ] Versão do texto descrita indicada; situação conferida na data da sessão
- [ ] Documentos da tramitação citados por nome e data; fontes externas com link
- [ ] Lista "Fontes" ao fim do resumo; documentos não lidos informados
- [ ] Cabeçalho "ITEM X - SIGLA Nº/ANO" correto; ementa oficial sem alterações
- [ ] Relator: Plenário → última comissão → em branco; com ad hoc, usar o designado e informar o ad hoc ao Eduardo
- [ ] Rótulos "Autor/Autora" e "Relator/Relatora" conforme a pessoa (nunca "(a)"); legenda "(PARTIDO/UF)"
- [ ] Fotos oficiais (senador: Senado; deputado: biografia completa, fundo branco); partido conferido na biografia atual
- [ ] Tramitação só com etapas do Senado; etapa atual em vermelho; etiquetas
- [ ] Objetivos com fonte; divergências apontadas
- [ ] "Resposta do texto" sem interpretação própria apresentada como fato
- [ ] Seções obrigatórias da espécie presentes
- [ ] Estilo conforme a seção 3.8 (brasão claro, cartões com ícone, faixa-título do assunto)
- [ ] Nada estourando caixa; A4, 1 página salvo justificativa de tamanho/complexidade
- [ ] Prévia aprovada antes do commit
